import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SiteService } from '../Services/site.service';
import { Site } from '../sites/sites.component';

@Component({
  selector: 'app-addsite',
  templateUrl: './addsite.component.html',
  styleUrls: ['./addsite.component.css']
})
export class AddsiteComponent implements OnInit {

  newSite:Site={ SiteId:0, SiteName:'', SiteLocation:'',Address:'',ContactEmail:'', ContactNumber:''};
  errorMessage:string='';
  constructor(private siteService:SiteService,private router:Router) { }

  ngOnInit(): void {
  }

  SaveProduct(){
   
    this.siteService.SaveSite(this.newSite).subscribe(
      data=>{
        if(data!=null && data>0){
          this.errorMessage='';
          this.router.navigate(['sites']);
        }
        else{
          this.router.navigate(['sites']);       
        }
      },
      error=>{
        this.errorMessage='Save Failed!, Please contact Admin!';
        console.log('error');
      }
    );
  }

}



