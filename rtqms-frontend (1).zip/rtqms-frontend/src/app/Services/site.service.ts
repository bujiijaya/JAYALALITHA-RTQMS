import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Vechicle } from '../progressview/progressview.component';
import { Site } from '../sites/sites.component';

@Injectable({
  providedIn: 'root'
})
export class SiteService {
  url:string='https://localhost:44387/api/Site/';
  constructor(private http:HttpClient) { }
  getAllSites()
  {
    return this.http.get<Site[]>(this.url+'GetAllSites');
  }

  getSiteforSupervisor(supervisor:number)
  {
    return this.http.get<Site[]>(this.url+'GetProuductsByCategory/'+supervisor);
  }

  getVechiclesforSite(site:number)
  {
    return this.http.get<Vechicle[]>(this.url+'GetSiteVehicles/'+site);
  }
  SaveSite(newSite:Site){
    return this.http.post<number>(this.url+'PostSiteDetails/',newSite);
}

}