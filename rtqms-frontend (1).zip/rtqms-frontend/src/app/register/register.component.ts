import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {  User } from '../products/products.component';
import { LoginService } from '../Services/login.service';
import { ProductService } from '../Services/product.service';
import { SessionService } from '../Services/session.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  newUser:User={ UserId:0, FirstName:'',LastName:'', Email:'',MobileNumber:'',Password:'', Role:'',CreatedOn:'11/05/2022', UpdatedOn:'11/05/2022',IsActive:true};
  errorMessage:string='';
  loggedInCustomerId: number=0;
  loggedInFullName: string;
  customerCartCount: number;
  regType: string;
  constructor(private loginService:LoginService,private router:Router,private sessionService:SessionService) { }

  ngOnInit(): void {
    this.regType=localStorage.getItem("regType");
    this.sessionService.sharedMessage.subscribe(message => 
      {
        this.loggedInCustomerId=message.CustomerId;
        this.loggedInFullName=message.FullName;
        this.customerCartCount=message.CartProducts;
      }
     );
  }

  SaveUser(){
   
     this.newUser.Role=this.regType;
  
    this.loginService.SaveUser(this.newUser).subscribe(
      data=>{
        if(this.regType=='Engineer'){
          this.router.navigate(['/engineers']);
        }
        else{
          this.router.navigate(['/supervisors']);
        }
      },
      error=>{
        this.errorMessage='Save Failed!, Please contact Admin!';
        console.log('error');
      }
    );
  }

}
