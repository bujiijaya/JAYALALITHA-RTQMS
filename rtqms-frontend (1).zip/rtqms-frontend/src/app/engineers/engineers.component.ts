import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../Services/customer.service';
import { LoginService } from '../Services/login.service';
import { SessionService } from '../Services/session.service';
import { SharedService } from '../Services/shared.service';
import { User } from '../sites/sites.component';

@Component({
  selector: 'app-engineers',
  templateUrl: './engineers.component.html',
  styleUrls: ['./engineers.component.css']
})
export class EngineersComponent implements OnInit {

  sites:User[];
  filterData:User[];
  selectedCategory: number=1;
  loggedInCustomerId:number;
  loggedInFullName:string;
  customerCartCount:number;
  query:string;
  regType: string;
   constructor(private router:Router,private customerService:CustomerService,private sharedService:SharedService,private sessionService:SessionService,private loginService:LoginService) { }
 
   ngOnInit(): void {
    this.regType=localStorage.getItem("regType"); 
     this.sessionService.sharedMessage.subscribe(message => 
       {
         this.loggedInCustomerId=message.CustomerId;
         this.loggedInFullName=message.FullName;
         this.customerCartCount=message.CartProducts;
       }
      );
     
 this.sharedService.sharedMessage.subscribe(message => 
   {
     this.getUsersByRole('2');
    // this.selectedCategory = message;
     //this.getProductsByCategory(Number(this.selectedCategory));
   }
  );
 
 
   }
 
  
 
   getUsersByRole(role:string)
   {
     this.loginService.getUsersByRole(role).subscribe(data=>{
      this.filterData=data;
     });
   }
 
   // applyFilter(){
   //   this.filterData= this.products.filter(i=> i.Category.toLowerCase().includes(this.selectedCategory.toLowerCase()));
   // }
 
   addEngineer(){
    localStorage.setItem("regType",'Engineer');
   this.router.navigate(['register']);
   }
 
   // AddtoCart(ProductId)
   // {
   //   this.sessionService.ChangeLoginStatus({FullName:this.loggedInFullName,CustomerId:this.loggedInCustomerId,CartProducts:this.customerCartCount+1});         
   //   var newCart:Cart={CartId:0 ,CustomerId:this.loggedInCustomerId, Product:ProductId,Qty:1};
   //   this.customerService.SaveProductsTothCart(newCart).subscribe(
   //     data=>{
   //       if(data!=null && data>0){
           
   //         console.log("Save Success");
   //       }
   //       else{
   //         console.log("Save Failed");
   //        //this.errorMessage='Save Failed.';          
   //       }
   //     },
   //     error=>{
   //       // this.errorMessage='Save Failed!, Please contact Admin!';
   //       console.log('error');
   //     }
   //   );
   //   //logic to save in DB    
   // }
 
 }
