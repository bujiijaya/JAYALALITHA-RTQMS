import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProgressviewComponent } from './progressview.component';

describe('ProgressviewComponent', () => {
  let component: ProgressviewComponent;
  let fixture: ComponentFixture<ProgressviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProgressviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProgressviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
