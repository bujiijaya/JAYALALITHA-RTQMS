export class Product {
    ProductId:number;
    ProductName:string;
    UnitPrice:number;
    StockAvailable:number;
}
