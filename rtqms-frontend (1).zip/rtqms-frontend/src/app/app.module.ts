import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductsComponent } from './products/products.component';
import { HomeComponent } from './home/home.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { CartComponent } from './cart/cart.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { RegisterComponent } from './register/register.component';
import { AddProductComponent } from './add-product/add-product.component';
import { SharedService } from './Services/shared.service';
import {ProductService} from './Services/product.service';
import { HttpClientModule } from '@angular/common/http';
import { SidebarComponent } from './sidebar/sidebar.component';
import { ProductdetailsComponent } from './productdetails/productdetails.component';
import {LoginService} from './Services/login.service';
import { FormsModule }   from '@angular/forms';
import { CustomerdashboardComponent } from './customerdashboard/customerdashboard.component';
import {SessionService} from './Services/session.service';
import {CustomerService} from './Services/customer.service';
import {SiteService} from './Services/site.service';
import { BillComponent } from './bill/bill.component';
import{SearchPipe} from './Services/ProductSearchPipe';
import { QualityfactorsComponent } from './qualityfactors/qualityfactors.component';
import { SitesComponent } from './sites/sites.component';
import { ProgressviewComponent } from './progressview/progressview.component';
import { SupervisorsComponent } from './supervisors/supervisors.component';
import { EngineersComponent } from './engineers/engineers.component';
import { AddsiteComponent } from './addsite/addsite.component';


@NgModule({
  declarations: [
    AppComponent,
    ProductsComponent,
    HomeComponent,
    AboutUsComponent,
    ContactUsComponent,
    CartComponent,
    SignInComponent,
    RegisterComponent,
    AddProductComponent,
    SidebarComponent,
    ProductdetailsComponent,
    CustomerdashboardComponent,
    BillComponent,
    SearchPipe,
    QualityfactorsComponent,
    SitesComponent,
    ProgressviewComponent,
    SupervisorsComponent,
    EngineersComponent,
    AddsiteComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [SharedService,ProductService,LoginService,SessionService,CustomerService,SiteService],
  bootstrap: [AppComponent]
})
export class AppModule { }
