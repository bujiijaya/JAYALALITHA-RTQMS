import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../Services/customer.service';
import { ProductService } from '../Services/product.service';
import { SessionService } from '../Services/session.service';
import { SharedService } from '../Services/shared.service';
import { SiteService } from '../Services/site.service';

@Component({
  selector: 'app-sites',
  templateUrl: './sites.component.html',
  styleUrls: ['./sites.component.css']
})
export class SitesComponent implements OnInit {

  sites:Site[];
 filterData:Site[];
 selectedCategory: number=1;
 loggedInCustomerId:number;
 loggedInFullName:string;
 customerCartCount:number;
 query:string;
  constructor(private router:Router,private customerService:CustomerService,private sharedService:SharedService,private sessionService:SessionService,private siteService:SiteService) { }

  ngOnInit(): void {
    
    this.sessionService.sharedMessage.subscribe(message => 
      {
        this.loggedInCustomerId=message.CustomerId;
        this.loggedInFullName=message.FullName;
        this.customerCartCount=message.CartProducts;
      }
     );
    
this.sharedService.sharedMessage.subscribe(message => 
  {
    this.getAllSites();
   // this.selectedCategory = message;
    //this.getProductsByCategory(Number(this.selectedCategory));
  }
 );


  }

  getAllSites()
  {
    this.siteService.getAllSites().subscribe(data=>{
      this.sites=data;  
      this.filterData=this.sites;    
    });    
  }

  getSupervisorsSite(supervisor:number)
  {
    this.siteService.getSiteforSupervisor(supervisor).subscribe(data=>{
     this.filterData=data;
    });
  }

  // applyFilter(){
  //   this.filterData= this.products.filter(i=> i.Category.toLowerCase().includes(this.selectedCategory.toLowerCase()));
  // }

  addNewSite(){
  this.router.navigate(['addsite']);
  }

  // AddtoCart(ProductId)
  // {
  //   this.sessionService.ChangeLoginStatus({FullName:this.loggedInFullName,CustomerId:this.loggedInCustomerId,CartProducts:this.customerCartCount+1});         
  //   var newCart:Cart={CartId:0 ,CustomerId:this.loggedInCustomerId, Product:ProductId,Qty:1};
  //   this.customerService.SaveProductsTothCart(newCart).subscribe(
  //     data=>{
  //       if(data!=null && data>0){
          
  //         console.log("Save Success");
  //       }
  //       else{
  //         console.log("Save Failed");
  //        //this.errorMessage='Save Failed.';          
  //       }
  //     },
  //     error=>{
  //       // this.errorMessage='Save Failed!, Please contact Admin!';
  //       console.log('error');
  //     }
  //   );
  //   //logic to save in DB    
  // }

}

export class Site {
  SiteId:number;
  SiteName:string;
  SiteLocation:string;
  Address:string;
  ContactEmail:string;
  ContactNumber:string;  
}

export class Product {
  ProductId:number;
  Category:string;
  ProductName:string;
  UnitPrice:number;
  UnitsInStock:number;
  CreatedOn:string;  
  Description:string;
  ImageUrl:string;
  IsActive:boolean;
  SKU:string;
  UpdatedOn:string;
}

export class User {
  UserId:number;
  FirstName:string;
  LastName:string;
  Email:string;
  MobileNumber:string;
  Password:string;  
  Role:string;  
  IsActive:boolean;
  CreatedOn:string;
  UpdatedOn:string;
}
