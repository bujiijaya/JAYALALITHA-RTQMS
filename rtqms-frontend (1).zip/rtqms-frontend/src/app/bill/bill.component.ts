import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerCart } from '../cart/cart.component';
import { CustomerService } from '../Services/customer.service';
import { SessionService } from '../Services/session.service';

@Component({
  selector: 'app-bill',
  templateUrl: './bill.component.html',
  styleUrls: ['./bill.component.css']
})
export class BillComponent implements OnInit {
  CustomerData:any;
  CustomerId:number;
  CustomerCartCount:number;
  CustomerCart:CustomerCart[];
  total:number=0;
  noofProducts:number=0;
  constructor(private sessionService:SessionService,private customerService:CustomerService,private router:Router) { }

  ngOnInit(): void {
    this.sessionService.sharedMessage.subscribe(message => 
      {       
        this.CustomerId=message.CustomerId;
        this.CustomerCartCount=message.CartProducts;

        this.customerService.getCustomerDetails(message.CustomerId).subscribe(data=>{
          this.CustomerData=data;         
         });


        this.customerService.getCustomerCart(message.CustomerId).subscribe(data=>{
          this.CustomerCart=data;
          this.noofProducts=data.length;
          this.CustomerCart.forEach((keys : CustomerCart, vals :any) => {
            this.total=this.total+keys.UnitPrice;
        })
         });

      }
     );
  }

  SaveCustomerTransaction()
  {
   var transaction:any={TransactionId:0,TransactionDate:'',TransactionAmount:this.total, NoofProducts:this.noofProducts, TransactionStatus:true, ProductId:0, CustomerId:this.CustomerId };
    this.customerService.SaveCustomerTransaction(transaction).subscribe(
      data=>{
        if(data!=null && data>0){          
          console.log("Save Success");
        }
        else{
          console.log("Save Failed");
         //this.errorMessage='Save Failed.';          
        }
      },
      error=>{
        // this.errorMessage='Save Failed!, Please contact Admin!';
        console.log('error');
      }
    );
  }

}
