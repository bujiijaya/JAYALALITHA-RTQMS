import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QualityfactorsComponent } from './qualityfactors.component';

describe('QualityfactorsComponent', () => {
  let component: QualityfactorsComponent;
  let fixture: ComponentFixture<QualityfactorsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QualityfactorsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QualityfactorsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
