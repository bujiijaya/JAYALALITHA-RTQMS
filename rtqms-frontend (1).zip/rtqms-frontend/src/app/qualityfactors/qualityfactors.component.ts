import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qualityfactors',
  templateUrl: './qualityfactors.component.html',
  styleUrls: ['./qualityfactors.component.css']
})
export class QualityfactorsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
