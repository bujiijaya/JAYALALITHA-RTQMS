import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ProductsComponent } from './products/products.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { CartComponent } from './cart/cart.component';
import { AddProductComponent } from './add-product/add-product.component';
import { ProductdetailsComponent } from './productdetails/productdetails.component';
import { CustomerdashboardComponent } from './customerdashboard/customerdashboard.component';
import { BillComponent } from './bill/bill.component';
import { RegisterComponent } from './register/register.component';
import { QualityfactorsComponent } from './qualityfactors/qualityfactors.component';
import { SitesComponent } from './sites/sites.component';
import { SupervisorsComponent } from './supervisors/supervisors.component';
import { EngineersComponent } from './engineers/engineers.component';
import { ProgressviewComponent } from './progressview/progressview.component';
import { AddsiteComponent } from './addsite/addsite.component';

const routes: Routes = [
  { path: '',   redirectTo: '/home', pathMatch: 'full' },  
  {path:'home',component:HomeComponent},
  {path:'products',component:ProductsComponent},
  {path:'addproduct',component:AddProductComponent},
  {path:'aboutus',component:AboutUsComponent},
  {path:'contactus',component:ContactUsComponent},
  {path:'login',component:SignInComponent},
  {path:'cart',component:CartComponent},
  {path:'proudctDetails',component:ProductdetailsComponent},
  {path:'customerdashboard',component:CustomerdashboardComponent},
  {path:'bill',component:BillComponent},
  {path:'register',component:RegisterComponent},
  {path:'sites',component:SitesComponent},
  {path:'supervisors',component:SupervisorsComponent},
  {path:'engineers',component:EngineersComponent},
  {path:'progressview',component:ProgressviewComponent},
  {path:'qualityfactors',component:QualityfactorsComponent},
  {path:'addsite',component:AddsiteComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
